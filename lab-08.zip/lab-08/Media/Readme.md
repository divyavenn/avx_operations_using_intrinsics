Directory to store images
